package com.employee.application;

import java.util.HashSet;
import java.util.Scanner;

public class EmployeeService {
	HashSet<Employee> empSet=new HashSet<Employee>();
	Employee emp1=new Employee(101,"Agni",24,"IT","Developer",250000);
	Employee emp2=new Employee(102,"Priya",23,"CO","Tester",50000);
	Employee emp3=new Employee(103,"Maxi",20,"Admin","Devops Engg",5000);
	Employee emp4=new Employee(104,"Ann",25,"CO","System Engg",70000);
	Scanner sc=new Scanner(System.in);
	boolean found=false;
	int id;
	String name;
	int age;
	String department;
	String designation;
	double salary;
	public EmployeeService() {
		empSet.add(emp1);
		empSet.add(emp2);
		empSet.add(emp3);
		empSet.add(emp4);
	}
	public void viewAllEmployee() {
		for(Employee emp:empSet) {
			System.out.println(emp);
		}
	}
	public void viewEmpBasedOnId() {
		System.out.println("Enter id:");
		id=sc.nextInt();
		for(Employee emp:empSet) {
			if(emp.getId()==id) {
				System.out.println(emp);
				found=true;
			}
		}
		if(!found) {
			System.out.println("Employee with this id is not present");
		}
	}
	public void updateEmployee() {
		System.out.println("Enter id:");
		id=sc.nextInt();
		for(Employee emp:empSet) {
			if(emp.getId()==id) {
				System.out.println("Enter Name : ");
				name=sc.next();
				System.out.println("Enter the salary : ");
				salary=sc.nextDouble();
				emp.setName(name);
				emp.setSalary(salary);
				System.out.println("Updated Details of Employee are : ");
				System.out.println(emp);
				found=true;
				
			}
		}
	}
}
