package com.employee.application;

import java.util.Scanner;

public class Main {
	EmployeeService empService=new EmployeeService();
	static boolean ordering=true;
	public static void menu() {
		System.out.println("*****Welcome to Employee Management System*****"
				+"\n1.Add Employee"
				+"\n2.View Employee"
				+"\n3.Update Employee"
				+"\n4.Delete Employee"
				+"\n5.View All Employee"
				+"\n6.Exit");
	}
	public static void main(String[] args) {
		menu();
		Scanner sc=new Scanner(System.in);
		EmployeeService empService=new EmployeeService();
		do {
			
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Add Employee");
				break;
			case 2:	
				System.out.println("View Employee");
				empService.viewEmpBasedOnId();
				break;
			case 3:
				System.out.println("Update Employee");
				empService.updateEmployee();
				break;
			case 4:
				System.out.println("Delete Employee");
				break;
			case 5:
				System.out.println("View All Employee");
				empService.viewAllEmployee();
				break;
			case 6:
				System.out.println("Thanks for using the application");
				System.exit(0);
			default:
				System.out.println("Please enter a valid choice");	
				break;
			}
		}while(ordering);

	}

}
